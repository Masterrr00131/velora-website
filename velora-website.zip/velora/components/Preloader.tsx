"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export default function Preloader() {
  const [visible, setVisible] = useState(true);
  const [skip, setSkip] = useState(false);

  useEffect(() => {
    // Only perform the full cinematic open once per browser session.
    const hasSeenIntro = sessionStorage.getItem("velora-intro-seen");
    if (hasSeenIntro) {
      setSkip(true);
      setVisible(false);
      return;
    }

    document.body.style.overflow = "hidden";

    const timeout = setTimeout(() => {
      sessionStorage.setItem("velora-intro-seen", "true");
      setVisible(false);
      document.body.style.overflow = "";
    }, 2600);

    return () => clearTimeout(timeout);
  }, []);

  if (skip) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="preloader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-ink"
        >
          <div className="flex flex-col items-center gap-6">
            <motion.h1
              initial={{ opacity: 0, letterSpacing: "0.15em" }}
              animate={{ opacity: 1, letterSpacing: "0.42em" }}
              transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
              className="font-display text-4xl sm:text-5xl font-medium text-paper"
            >
              VELORA
            </motion.h1>
            <motion.div
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1], delay: 1.0 }}
              className="h-px max-w-[140px] w-full bg-gold/70"
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
