"use client";

import Image from "next/image";
import RevealSection from "./RevealSection";
import { lifestyleImages } from "@/lib/data";

export default function Lifestyle() {
  return (
    <section className="relative bg-ink py-28 sm:py-36 lg:py-44">
      <div className="mx-auto max-w-editorial px-6 sm:px-10 lg:px-16">
        <RevealSection className="max-w-xl mb-20 lg:mb-24">
          <span className="text-[11px] tracking-[0.4em] uppercase text-gold">
            Chapter III — The Ritual
          </span>
          <h2 className="mt-6 font-display text-4xl sm:text-5xl text-paper text-balance">
            A life, unhurried.
          </h2>
        </RevealSection>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {lifestyleImages.map((item, i) => (
            <RevealSection
              key={item.id}
              delay={i * 0.1}
              className={item.span === "large" ? "md:col-span-2" : ""}
            >
              <figure className="group relative overflow-hidden">
                <div
                  className={`relative w-full ${
                    item.span === "large"
                      ? "aspect-[16/8]"
                      : "aspect-[4/5]"
                  }`}
                >
                  <Image
                    src={item.image}
                    alt={item.caption}
                    fill
                    sizes="(min-width: 768px) 50vw, 100vw"
                    className="object-cover transition-transform duration-[1.4s] ease-luxury group-hover:scale-[1.04]"
                  />
                  <div className="absolute inset-0 bg-ink/0 group-hover:bg-ink/10 transition-colors duration-700" />
                </div>
                <figcaption className="mt-4 text-[11px] tracking-[0.2em] uppercase text-mist">
                  {item.caption}
                </figcaption>
              </figure>
            </RevealSection>
          ))}
        </div>
      </div>
    </section>
  );
}
