export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative bg-ink border-t border-white/[0.06] py-16">
      <div className="mx-auto max-w-editorial px-6 sm:px-10 lg:px-16">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-10">
          <div>
            <span className="font-display text-2xl tracking-[0.22em] text-paper">
              VELORA
            </span>
            <p className="mt-3 text-mist font-light text-xs max-w-xs leading-relaxed">
              Premium coffee roastery. Crafted for those who expect more.
            </p>
          </div>

          <ul className="flex flex-wrap gap-x-10 gap-y-4">
            <li>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] tracking-[0.25em] uppercase text-mist hover:text-gold transition-colors duration-500"
              >
                Instagram
              </a>
            </li>
            <li>
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] tracking-[0.25em] uppercase text-mist hover:text-gold transition-colors duration-500"
              >
                TikTok
              </a>
            </li>
            <li>
              <a
                href="mailto:hello@velora-coffee.com"
                className="text-[11px] tracking-[0.25em] uppercase text-mist hover:text-gold transition-colors duration-500"
              >
                hello@velora-coffee.com
              </a>
            </li>
          </ul>
        </div>

        <div className="velora-line-solid mt-14 mb-8" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <p className="text-[11px] tracking-[0.1em] text-mist/70">
            © {year} Velora Coffee Roastery. All rights reserved.
          </p>
          <p className="text-[11px] tracking-[0.1em] text-mist/70">
            Roasted with precision, worldwide.
          </p>
        </div>
      </div>
    </footer>
  );
}
