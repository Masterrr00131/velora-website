"use client";

import Image from "next/image";
import RevealSection from "./RevealSection";
import { instagramFeed } from "@/lib/data";

export default function InstagramFeed() {
  return (
    <section className="relative bg-ink py-28 sm:py-36 lg:py-40">
      <div className="mx-auto max-w-editorial px-6 sm:px-10 lg:px-16">
        <RevealSection className="flex flex-col sm:flex-row sm:items-end sm:justify-between mb-14 lg:mb-16 gap-4">
          <div>
            <span className="text-[11px] tracking-[0.4em] uppercase text-gold">
              Follow
            </span>
            <h2 className="mt-6 font-display text-4xl sm:text-5xl text-paper">
              @velora.coffee
            </h2>
          </div>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] tracking-[0.3em] uppercase text-mist hover:text-paper transition-colors border-b border-white/20 hover:border-gold pb-1 w-fit"
          >
            View Profile
          </a>
        </RevealSection>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1">
          {instagramFeed.map((src, i) => (
            <RevealSection key={src} delay={i * 0.06}>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="group relative block aspect-square overflow-hidden"
              >
                <Image
                  src={src}
                  alt="Velora on Instagram"
                  fill
                  sizes="(min-width: 640px) 33vw, 50vw"
                  className="object-cover transition-transform duration-[1.2s] ease-luxury group-hover:scale-[1.08]"
                />
                <div className="absolute inset-0 bg-ink/0 group-hover:bg-ink/40 transition-colors duration-500 flex items-center justify-center">
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-500 text-[11px] tracking-[0.3em] uppercase text-paper">
                    View
                  </span>
                </div>
              </a>
            </RevealSection>
          ))}
        </div>
      </div>
    </section>
  );
}
