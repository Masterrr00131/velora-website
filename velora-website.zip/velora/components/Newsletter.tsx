"use client";

import { useState, FormEvent } from "react";
import RevealSection from "./RevealSection";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "submitted">("idle");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!email) return;
    // Wire up to your email provider (Klaviyo, Mailchimp, Resend, etc.)
    setStatus("submitted");
  };

  return (
    <section id="contact" className="relative bg-charcoal py-28 sm:py-36">
      <div className="mx-auto max-w-editorial px-6 sm:px-10 lg:px-16">
        <RevealSection className="max-w-xl mx-auto text-center flex flex-col items-center">
          <span className="text-[11px] tracking-[0.4em] uppercase text-gold">
            Correspondence
          </span>
          <h2 className="mt-6 font-display text-3xl sm:text-4xl text-paper text-balance">
            Be first to know.
          </h2>
          <p className="mt-5 text-mist font-light text-sm leading-[1.8] max-w-sm">
            New origins, limited roasts, and private tastings — reserved for
            those on our list.
          </p>

          {status === "idle" ? (
            <form
              onSubmit={handleSubmit}
              className="mt-10 w-full flex flex-col sm:flex-row items-stretch gap-4 sm:gap-0 sm:border-b sm:border-white/15 focus-within:sm:border-gold transition-colors duration-500"
            >
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                aria-label="Email address"
                className="flex-1 bg-transparent border border-white/15 sm:border-none px-4 py-4 text-sm text-paper placeholder:text-mist/70 focus:outline-none"
              />
              <button
                type="submit"
                className="shrink-0 px-8 py-4 text-[11px] tracking-[0.3em] uppercase text-paper border border-gold/50 hover:bg-gold hover:text-ink transition-colors duration-500"
              >
                Subscribe
              </button>
            </form>
          ) : (
            <p className="mt-10 text-gold text-sm tracking-[0.15em] uppercase">
              Thank you — welcome to Velora.
            </p>
          )}
        </RevealSection>
      </div>
    </section>
  );
}
