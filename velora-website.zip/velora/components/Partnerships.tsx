"use client";

import RevealSection from "./RevealSection";
import { partnerships } from "@/lib/data";

export default function Partnerships() {
  return (
    <section
      id="partnerships"
      className="relative bg-charcoal py-28 sm:py-36 lg:py-44"
    >
      <div className="mx-auto max-w-editorial px-6 sm:px-10 lg:px-16">
        <RevealSection className="max-w-xl mb-20 lg:mb-24">
          <span className="text-[11px] tracking-[0.4em] uppercase text-gold">
            Chapter IV — Alliances
          </span>
          <h2 className="mt-6 font-display text-4xl sm:text-5xl text-paper text-balance">
            Partnerships
          </h2>
          <p className="mt-6 text-mist font-light leading-[1.8] text-[15px]">
            Velora partners with institutions that share our standard —
            where precision, discipline, and performance are non-negotiable.
          </p>
        </RevealSection>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-white/[0.06]">
          {partnerships.map((item, i) => (
            <RevealSection key={item.id} delay={i * 0.1} className="bg-charcoal">
              <div className="group relative h-full p-10 lg:p-12 flex flex-col justify-between min-h-[240px] overflow-hidden">
                <div className="absolute inset-0 border border-transparent group-hover:border-gold/30 transition-colors duration-700" />
                <span className="text-[11px] tracking-[0.3em] uppercase text-gold">
                  0{i + 1}
                </span>
                <div className="mt-auto">
                  <h3 className="font-display text-2xl sm:text-3xl text-paper">
                    {item.title}
                  </h3>
                  <p className="mt-4 text-mist font-light text-sm leading-[1.85] max-w-sm">
                    {item.description}
                  </p>
                </div>
              </div>
            </RevealSection>
          ))}
        </div>
      </div>
    </section>
  );
}
