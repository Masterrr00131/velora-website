"use client";

import { motion } from "framer-motion";
import Image from "next/image";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function Hero() {
  return (
    <section
      id="home"
      className="relative h-[100svh] w-full flex items-center justify-center overflow-hidden bg-ink"
    >
      {/* Cinematic background */}
      <div className="absolute inset-0">
        <Image
          src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=2400&auto=format&fit=crop"
          alt="Coffee poured slowly under warm cinematic light"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center scale-[1.06]"
        />
        {/* Warm dark scrim for legibility — not a decorative gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-ink/80 via-ink/55 to-ink" />
        <div className="absolute inset-0 bg-ink/20" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center px-6">
        <motion.span
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 3.0, ease: EASE }}
          className="mb-6 text-[11px] sm:text-xs tracking-[0.45em] uppercase text-gold"
        >
          Est. Roastery
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 3.15, ease: EASE }}
          className="font-display text-[18vw] leading-[0.9] sm:text-[9rem] md:text-[11rem] font-medium text-paper tracking-[0.02em]"
        >
          VELORA
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 3.4, ease: EASE }}
          className="mt-6 text-sm sm:text-base tracking-[0.32em] uppercase text-mist"
        >
          Premium Coffee Roastery
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 3.65, ease: EASE }}
          className="mt-12"
        >
          <a
            href="#about"
            className="group relative inline-flex items-center gap-3 border border-gold/50 px-9 py-4 text-[11px] tracking-[0.32em] uppercase text-paper transition-colors duration-500 hover:border-gold"
          >
            <span className="absolute inset-0 -z-10 bg-gold origin-left scale-x-0 transition-transform duration-500 ease-luxury group-hover:scale-x-100" />
            <span className="transition-colors duration-500 group-hover:text-ink">
              Discover
            </span>
          </a>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 4.1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3"
      >
        <div className="h-12 w-px bg-gradient-to-b from-gold/70 to-transparent" />
        <span className="text-[10px] tracking-[0.3em] uppercase text-mist">
          Scroll
        </span>
      </motion.div>
    </section>
  );
}
