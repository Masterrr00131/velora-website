"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import RevealSection from "./RevealSection";
import { coffeeCollection } from "@/lib/data";

export default function CoffeeCollection() {
  return (
    <section id="coffee" className="relative bg-charcoal py-28 sm:py-36 lg:py-44">
      <div className="mx-auto max-w-editorial px-6 sm:px-10 lg:px-16">
        <RevealSection className="max-w-xl mb-20 lg:mb-24">
          <span className="text-[11px] tracking-[0.4em] uppercase text-gold">
            Chapter II — Craft
          </span>
          <h2 className="mt-6 font-display text-4xl sm:text-5xl text-paper text-balance">
            The Collection
          </h2>
          <p className="mt-6 text-mist font-light leading-[1.8] text-[15px]">
            Three preparations. Three disciplines. Each one a complete
            expression of a single origin, roasted for its own method alone.
          </p>
        </RevealSection>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/[0.06]">
          {coffeeCollection.map((item, i) => (
            <RevealSection key={item.id} delay={i * 0.12} className="bg-charcoal">
              <motion.article
                whileHover="hover"
                className="group relative h-full flex flex-col bg-charcoal"
              >
                <div className="relative aspect-[3/4] w-full overflow-hidden">
                  <motion.div
                    variants={{ hover: { scale: 1.06 } }}
                    transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                    className="absolute inset-0"
                  >
                    <Image
                      src={item.image}
                      alt={`${item.name} — ${item.origin}`}
                      fill
                      sizes="(min-width: 768px) 33vw, 100vw"
                      className="object-cover"
                    />
                  </motion.div>
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/10 to-transparent" />

                  <div className="absolute bottom-0 left-0 right-0 p-8">
                    <span className="text-[10px] tracking-[0.3em] uppercase text-gold">
                      {item.origin}
                    </span>
                    <h3 className="mt-3 font-display text-3xl text-paper">
                      {item.name}
                    </h3>
                  </div>
                </div>

                <div className="p-8 flex-1 flex flex-col">
                  <p className="text-mist font-light text-sm leading-[1.85] flex-1">
                    {item.description}
                  </p>
                  <motion.div
                    variants={{ hover: { width: "100%" } }}
                    initial={{ width: "24px" }}
                    transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                    className="mt-8 h-px bg-gold/70"
                  />
                </div>
              </motion.article>
            </RevealSection>
          ))}
        </div>
      </div>
    </section>
  );
}
