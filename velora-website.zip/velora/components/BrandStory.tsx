"use client";

import Image from "next/image";
import RevealSection from "./RevealSection";

export default function BrandStory() {
  return (
    <section id="about" className="relative bg-ink py-28 sm:py-36 lg:py-44">
      <div className="mx-auto max-w-editorial px-6 sm:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-14 lg:gap-8 items-center">
          {/* Text column */}
          <div className="lg:col-span-5 lg:order-1 order-2">
            <RevealSection>
              <span className="text-[11px] tracking-[0.4em] uppercase text-gold">
                Chapter I — Origin
              </span>
              <h2 className="mt-6 font-display text-4xl sm:text-5xl leading-[1.08] text-paper text-balance">
                Crafted for those who expect more.
              </h2>
            </RevealSection>

            <RevealSection delay={0.15}>
              <div className="velora-line my-10 max-w-[80px]" />
              <p className="text-mist leading-[1.9] text-[15px] sm:text-base font-light max-w-md">
                Velora began not as a brand, but as a standard — a refusal to
                accept coffee as commodity. Every bean is selected by hand,
                every roast profile measured to the second, every cup an
                exercise in restraint.
              </p>
              <p className="mt-6 text-mist leading-[1.9] text-[15px] sm:text-base font-light max-w-md">
                We do not chase trends. We pursue a single, uncompromising
                idea: that coffee, made with enough care, becomes a ritual
                worth returning to.
              </p>
            </RevealSection>

            <RevealSection delay={0.3}>
              <a
                href="#coffee"
                className="mt-10 inline-flex items-center gap-3 text-[11px] tracking-[0.32em] uppercase text-paper border-b border-gold/40 pb-2 hover:border-gold transition-colors duration-500"
              >
                Explore the Collection
              </a>
            </RevealSection>
          </div>

          {/* Image column */}
          <div className="lg:col-span-7 lg:order-2 order-1">
            <RevealSection y={48}>
              <div className="relative aspect-[4/5] sm:aspect-[16/11] w-full overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1447933601403-0c6688de566e?q=80&w=2000&auto=format&fit=crop"
                  alt="Velora master roaster inspecting beans in low, warm light"
                  fill
                  sizes="(min-width: 1024px) 60vw, 100vw"
                  className="object-cover grayscale-[15%]"
                />
                <div className="absolute inset-0 border border-white/10" />
              </div>
            </RevealSection>
          </div>
        </div>
      </div>
    </section>
  );
}
