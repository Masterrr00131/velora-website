import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";
import Preloader from "@/components/Preloader";

const displayFont = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-display",
  display: "swap",
});

const bodyFont = Inter({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

const SITE_URL = "https://velora-coffee.com";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "VELORA — Premium Coffee Roastery",
    template: "%s | VELORA",
  },
  description:
    "VELORA is a premium coffee roastery crafting Turkish, espresso, and filter coffee for those who expect more. Discover a rarefied ritual, roasted with precision.",
  keywords: [
    "VELORA",
    "luxury coffee",
    "premium coffee roastery",
    "specialty coffee",
    "Turkish coffee",
    "espresso",
    "filter coffee",
  ],
  authors: [{ name: "VELORA" }],
  openGraph: {
    title: "VELORA — Premium Coffee Roastery",
    description:
      "Crafted for those who expect more. A rarefied coffee ritual, roasted with precision.",
    url: SITE_URL,
    siteName: "VELORA",
    locale: "en_US",
    type: "website",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "VELORA Premium Coffee Roastery",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "VELORA — Premium Coffee Roastery",
    description: "Crafted for those who expect more.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export const viewport: Viewport = {
  themeColor: "#090909",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${displayFont.variable} ${bodyFont.variable}`}>
      <body className="font-body bg-ink text-paper antialiased">
        <Preloader />
        {children}
      </body>
    </html>
  );
}
