import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import BrandStory from "@/components/BrandStory";
import CoffeeCollection from "@/components/CoffeeCollection";
import Lifestyle from "@/components/Lifestyle";
import Partnerships from "@/components/Partnerships";
import InstagramFeed from "@/components/InstagramFeed";
import Newsletter from "@/components/Newsletter";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <BrandStory />
        <CoffeeCollection />
        <Lifestyle />
        <Partnerships />
        <InstagramFeed />
        <Newsletter />
      </main>
      <Footer />
    </>
  );
}
