# VELORA — Premium Coffee Roastery

A luxury coffee brand website built with Next.js 15 (App Router), React,
TypeScript, Tailwind CSS, and Framer Motion.

## Design language

- **Palette** — ink `#090909`, charcoal `#121212`, gold `#C6A15B`,
  paper `#F8F8F8`, mist `#9D9D9D`.
- **Type** — Cormorant Garamond (display) paired with Inter (body).
- **Signature motif** — a fine gold hairline used as a recurring divider,
  echoing a pour line / horological second hand. No rounded colorful
  buttons, no gradients-as-decoration, no glassmorphism.
- **Motion** — a single cinematic page-load sequence (black → VELORA
  fade-in → reveal, once per session), then quiet scroll reveals and
  restrained hover states throughout.

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Structure

```
app/
  layout.tsx        Root layout, fonts, SEO metadata
  page.tsx           Section composition
  globals.css        Base styles + signature line motif
  sitemap.ts         SEO sitemap
  robots.ts          SEO robots
components/
  Preloader.tsx       Cinematic intro (once per session)
  Navbar.tsx          Transparent sticky nav
  Hero.tsx            Full-screen hero
  BrandStory.tsx       "Crafted for those who expect more"
  CoffeeCollection.tsx Three coffee preparations
  Lifestyle.tsx        Editorial magazine grid
  Partnerships.tsx     Partner category cards
  InstagramFeed.tsx    Social grid
  Newsletter.tsx       Minimal email capture
  Footer.tsx
  RevealSection.tsx    Reusable scroll-reveal wrapper
lib/
  data.ts             All copy + content data in one place
```

## Notes for production

- Replace the Unsplash imagery in `lib/data.ts` and `Hero.tsx` with
  Velora's own photography — the `next/image` remote pattern for
  `images.unsplash.com` can be removed once you do.
- Wire `Newsletter.tsx`'s `handleSubmit` to your email provider
  (Klaviyo, Resend, Mailchimp, etc.).
- Add a real `/public/og-image.jpg` (1200×630) and `/public/favicon.ico`.
- Update the `SITE_URL` constant in `app/layout.tsx` and the base URLs
  in `app/sitemap.ts` / `app/robots.ts` to your production domain.
