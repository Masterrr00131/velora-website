export const coffeeCollection = [
  {
    id: "turkish",
    name: "Turkish Coffee",
    origin: "Yemen · Harar Highlands",
    description:
      "Ground to dust and simmered slow, our Turkish preparation holds the coffee's oldest ritual — dense, unfiltered, ceremonial.",
    image:
      "https://images.unsplash.com/photo-1621319332247-ce870cdad56c?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "espresso",
    name: "Espresso",
    origin: "Antigua · Volcán de Fuego",
    description:
      "Nine bars of pressure, eighteen grams of intent. A precise, syrupy concentrate built for those who take their coffee seriously.",
    image:
      "https://images.unsplash.com/photo-1509785307050-d4066910ec1e?q=80&w=1600&auto=format&fit=crop",
  },
  {
    id: "filter",
    name: "Filter Coffee",
    origin: "Yirgacheffe · Ethiopia",
    description:
      "A slow pour, a patient bloom. Clarity over intensity — bright, floral, and entirely unhurried.",
    image:
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1600&auto=format&fit=crop",
  },
];

export const lifestyleImages = [
  {
    id: 1,
    image:
      "https://images.unsplash.com/photo-1447933601403-0c6688de566e?q=80&w=1800&auto=format&fit=crop",
    caption: "First light, Vienna atelier",
    span: "large",
  },
  {
    id: 2,
    image:
      "https://images.unsplash.com/photo-1442512595331-e89e73853f31?q=80&w=1200&auto=format&fit=crop",
    caption: "The pour, unhurried",
    span: "small",
  },
  {
    id: 3,
    image:
      "https://images.unsplash.com/photo-1524350876685-274059332603?q=80&w=1200&auto=format&fit=crop",
    caption: "Roastery archive, No. 14",
    span: "small",
  },
  {
    id: 4,
    image:
      "https://images.unsplash.com/photo-1516575150278-77136aed6920?q=80&w=1800&auto=format&fit=crop",
    caption: "A quiet table, reserved",
    span: "large",
  },
];

export const partnerships = [
  {
    id: "esports",
    title: "Esports",
    description:
      "Focus, sustained. Velora fuels the world's most disciplined competitive teams through official roastery partnerships.",
  },
  {
    id: "sports",
    title: "Sports Clubs",
    description:
      "From training ground to boardroom — a coffee ritual built for peak performance and post-match precision.",
  },
  {
    id: "corporate",
    title: "Corporate",
    description:
      "Boardrooms deserve better. Bespoke roastery programs for enterprises who measure quality in every detail.",
  },
  {
    id: "premium",
    title: "Premium Businesses",
    description:
      "Hospitality groups, private members' clubs, and flagship boutiques — Velora as the signature of the house.",
  },
];

export const instagramFeed = [
  "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1442512595331-e89e73853f31?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1544787219-7f47ccb76574?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1524350876685-274059332603?q=80&w=900&auto=format&fit=crop",
];

export const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Coffee", href: "#coffee" },
  { label: "Partnerships", href: "#partnerships" },
  { label: "Contact", href: "#contact" },
];
